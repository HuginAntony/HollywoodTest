import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Tournament } from 'src/app/shared/models/tournament.model';
import { TournamentService } from 'src/app/shared/services/tournament.service';


@Component({
  selector: 'app-view-tournaments',
  templateUrl: './view-tournaments.component.html',
  styleUrls: ['./view-tournaments.component.css'],
  standalone: false
})
export class ViewTournamentsComponent implements OnInit {

  tournaments$: Observable<Tournament[]>;

  constructor(private tournamentService: TournamentService) { }

  ngOnInit(): void {
    this.tournaments$ = this.tournamentService.getAll();
  }
}
