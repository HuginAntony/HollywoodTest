import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-401-page',
  templateUrl: './401-page.component.html',
  styleUrls: ['./401-page.component.css'],
  standalone: false
})
export class AuthorisedPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
