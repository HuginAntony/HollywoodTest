import { EventDetailStatusNames } from '../enums/eventDetailStatusNames.enum';

export interface EventDetailStatus {
    eventDetailStatusId?: number;
    eventDetailStatusName?: EventDetailStatusNames;
}

